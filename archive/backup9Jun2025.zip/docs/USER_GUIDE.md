# SDTM Annotation Checker - User Guide
## Version 2.0

## 1. Introduction

Welcome to the SDTM Annotation Checker! This comprehensive tool validates annotated CRF PDFs against SDTM datasets, ensuring consistency and accuracy in clinical trial data management. The application provides both command-line and graphical interfaces to accommodate different user preferences and workflows.

## 2. Installation

### 2.1 Prerequisites
- py 3.8 or higher
- pip (py package installer)
- Virtual environment (recommended)

### 2.2 Installation Steps

1. **Clone the repository:**
   ```bash
   git clone <repository_url>
   cd annoSDTMCheck
   ```

2. **Create and activate virtual environment:**
   ```bash
   # Windows
   py -m venv .venv
   .venv\Scripts\activate

   # Linux/macOS
   py -m venv .venv
   source .venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Verify installation:**
   ```bash
   py -m sdtm_checker --help
   ```

## 3. Getting Started

### 3.1 Quick Start - GUI Mode
For users who prefer a graphical interface:

```bash
py -m sdtm_checker --gui
```

This launches the GUI where you can:
- Select PDF and SDTM files using file dialogs
- Configure validation settings
- Run validation and view results
- Manage configuration files

### 3.2 Quick Start - CLI Mode
For automated workflows and scripting:

```bash
py -m sdtm_checker validate /path/to/crf.pdf /path/to/sdtm/data --output report.xlsx
```

## 4. Command Line Interface

### 4.1 Available Commands

#### 4.1.1 validate - Full Validation Workflow
Validates annotations against SDTM datasets:

```bash
py -m sdtm_checker validate [OPTIONS] SDTM-DIR ANNOTATED-CRF
```

**Arguments:**
- `SDTM-DIR`: Directory containing SDTM datasets (.sas7bdat files)
- `ANNOTATED-CRF`: Path to annotated PDF file

**Options:**
- `--output PATH`: Output file path (default: validation_report.xlsx)
- `--config PATH`: Configuration file path
- `--help`: Show help message

**Example:**
```bash
py -m sdtm_checker validate ./sdtm_data/ ./crf/acrf_study001.pdf --output ./reports/validation_report.xlsx
```

#### 4.1.2 extract - Annotation Extraction
Extract annotations from PDF files:

```bash
py -m sdtm_checker extract [OPTIONS] PDF-FILE
```

**Options:**
- `--output PATH`: Output file path
- `--format [xfdf|excel]`: Output format (default: xfdf)

**Examples:**
```bash
# Extract to XFDF format
py -m sdtm_checker extract ./crf/study001.pdf --format xfdf

# Extract to Excel format
py -m sdtm_checker extract ./crf/study001.pdf --format excel --output annotations.xlsx
```



#### 4.1.3 info - Dataset Information
Display SDTM dataset information:

```bash
py -m sdtm_checker info [OPTIONS] SDTM-DIR
```

**Example:**
```bash
py -m sdtm_checker info ./sdtm_data/
```

### 4.2 Global Options
- `--gui`: Launch the graphical user interface
- `--version`: Show version information
- `--help`: Show help message

## 5. Configuration Management

### 5.1 Configuration File Structure
The tool uses YAML configuration files for customization:

```yaml
# File paths
paths:
  pdf_directory: "crf/"
  sdtm_directory: "sdtm_data/"
  output_directory: "output/"
  default_output_file: "validation_report.xlsx"

# Annotation patterns
annotation_patterns:
  patterns:
    - name: "DOMAIN_VAR"
      description: "Domain.Variable format (e.g., DM.SUBJID)"
      regex: "^([A-Z]{2})\.([A-Z0-9_]+)$"
      groups:
        domain: 1
        variable: 2
    - name: "DOMAIN_DASH_VAR"
      description: "Domain-Variable format (e.g., DM-SUBJID)"
      regex: "^([A-Z]{2})-([A-Z0-9_]+)$"
      groups:
        domain: 1
        variable: 2
    - name: "VARIABLE_ONLY"
      description: "Variable only (e.g., SUBJID)"
      regex: "^([A-Z0-9_]+)$"
      groups:
        variable: 1
  settings:
    case_sensitive: false
    fuzzy_matching: true
    fuzzy_threshold: 0.85

# Validation settings
validation:
  ignore_domains: []
  ignore_variables: ["STUDYID", "USUBJID"]
```

### 5.2 Using Configuration Files

**Command line:**
```bash
py -m sdtm_checker validate --config config.yaml sdtm_data/ crf.pdf
```

**GUI:**
Use the Configuration tab to load, edit, and save configuration files.

### 5.3 Configuration Management Features
- **Load Configuration**: Load existing YAML files
- **Save Configuration**: Save current settings
- **Reset to Default**: Restore default settings
- **Validation**: Automatic validation of configuration syntax
- **Pattern Testing**: Test regex patterns before saving

## 6. Graphical User Interface

### 6.1 Main Features
- **File Selection**: Browse and select PDF and SDTM files
- **Configuration Editor**: Visual configuration management
- **Progress Monitoring**: Real-time validation progress
- **Results Display**: Interactive results viewing

### 6.2 Configuration Tab
- **Path Management**: Set default directories
- **Pattern Editor**: Add/edit/test annotation patterns
- **Validation Settings**: Configure validation rules
- **Import/Export**: Share configurations with team

### 6.3 Running the GUI
```bash
# Option 1: Using the --gui flag (recommended)
py -m sdtm_checker --gui

# Option 2: Direct module execution
py -m sdtm_checker.gui.main
```

## 7. Advanced Features

### 7.1 Fuzzy Matching
The tool supports fuzzy matching for annotations with typos:

```yaml
annotation_patterns:
  settings:
    fuzzy_matching: true
    fuzzy_threshold: 0.85  # 85% similarity required
```

### 7.2 Custom Validation Rules
Customize validation behavior:

```yaml
validation:
  ignore_domains: ["RELREC", "SUPPAE"]  # Skip these domains
  ignore_variables: ["STUDYID", "USUBJID"]  # Skip these variables
```



### 7.3 Multiple Export Formats
Export annotations in different formats:

- **XFDF**: XML-based annotation format for archival
- **Excel**: Spreadsheet format for analysis and review

## 8. Understanding Results

### 8.1 Validation Report Structure
The Excel report contains multiple sheets:

1. **Summary**: Overall validation statistics
2. **Validation Results**: Detailed findings with severity levels
3. **Annotation Inventory**: Complete list of extracted annotations
4. **Dataset Information**: SDTM dataset metadata

### 8.2 Severity Levels
- **ERROR**: Critical issues requiring immediate attention
- **WARNING**: Potential issues that should be reviewed
- **INFO**: Informational messages and successful validations

### 8.3 Common Validation Results
- **Missing Variable**: Annotated variable not found in SDTM dataset
- **Domain Mismatch**: Variable found in different domain than annotated
- **Fuzzy Match**: Variable found with similar but not exact name
- **Successful Match**: Perfect match between annotation and SDTM variable

## 9. Troubleshooting

### 9.1 Common Issues and Solutions

#### Issue: ModuleNotFoundError
```
ModuleNotFoundError: No module named 'sdtm_checker'
```
**Solution:**
- Ensure virtual environment is activated
- Run from project root directory
- Verify installation: `pip install -r requirements.txt`

#### Issue: PDF Processing Errors
```
Error: Cannot extract annotations from PDF
```
**Solution:**
- Verify PDF file is not corrupted
- Check file permissions
- Ensure PDF contains annotations (not just text)

#### Issue: SDTM Dataset Reading Errors
```
Error: Cannot read SDTM dataset
```
**Solution:**
- Verify .sas7bdat files are valid
- Check file permissions
- Ensure pyreadstat is properly installed

#### Issue: Configuration Errors
```
Error: Invalid configuration file
```
**Solution:**
- Validate YAML syntax
- Check required fields are present
- Use GUI configuration editor for validation

### 9.2 Debug Mode
Enable verbose logging for troubleshooting:

```bash
py -m sdtm_checker validate --verbose sdtm_data/ crf.pdf
```

### 9.3 Log Files
The application creates log files:
- `file_access.log`: File access and processing log
- `sdtm-checker-run.log`: General application log

## 10. Best Practices

### 10.1 File Organization
```
project/
├── crf/                    # Annotated PDF files
├── sdtm_data/              # SDTM datasets (.sas7bdat)
├── config/                 # Configuration files
├── output/                 # Generated reports
└── logs/                   # Log files
```

### 10.2 Configuration Management
- Use descriptive names for custom patterns
- Test patterns before saving
- Share configurations with team members
- Keep backup of working configurations

### 10.3 Quality Assurance
- Review validation results systematically
- Address ERROR severity items first
- Investigate WARNING items case by case


### 10.4 Performance Optimization
- Process large datasets efficiently by monitoring memory usage
- Use appropriate fuzzy matching thresholds
- Monitor memory usage for large SDTM datasets

## 11. Integration and Automation

### 11.1 Automation Scripts
Windows batch file example:
```batch
@echo off
cd /d "C:\path\to\annoSDTMCheck"
call .venv\Scripts\activate.bat
py -m sdtm_checker validate sdtm_data\ crf\study001.pdf --output reports\validation_report.xlsx
```

### 11.2 PowerShell Script
```powershell
Set-Location "C:\path\to\annoSDTMCheck"
& .venv\Scripts\Activate.ps1
py -m sdtm_checker validate sdtm_data\ crf\study001.pdf --output reports\validation_report.xlsx
```

### 11.3 Continuous Integration
Integrate with CI/CD pipelines for automated validation:

```bash
# Example CI script
py -m sdtm_checker validate sdtm_data/ crf_file.pdf --output validation_report.xlsx
py -m sdtm_checker info sdtm_data/
```

## 12. Security Features

### 12.1 Path Validation
The application includes security features:
- Path traversal prevention
- File permission validation
- Safe file handling

### 12.2 Data Protection
- Encryption support for sensitive data
- Secure temporary file handling
- Audit logging for file access

## 13. Support and Resources

### 13.1 Documentation
- `README.md`: Project overview and quick start
- `PRD_CONSOLIDATED.md`: Complete product requirements
- `TECHNICAL_SPEC.md`: Technical implementation details

### 13.2 Getting Help
1. Check this user guide for common issues
2. Review log files for error details
3. Use `--help` option for command-specific help
4. Enable verbose logging for debugging

### 13.3 Reporting Issues
When reporting issues, include:
- Command used
- Error messages
- Log file contents
- System information (OS, py version)
- Sample files (if possible)

## 14. Frequently Asked Questions

**Q: What PDF annotation types are supported?**
A: Text annotations, highlights, comments, and other PyMuPDF-compatible annotation types.

**Q: Can I process multiple PDFs at once?**
A: Currently, the tool processes one PDF at a time. For multiple files, you can run the tool in a loop or script.

**Q: How do I customize annotation patterns?**
A: Edit the configuration file or use the GUI configuration editor to add custom regex patterns.

**Q: What SDTM file formats are supported?**
A: Currently supports .sas7bdat files (SAS datasets). XPT support is planned for future releases.

**Q: Can I share configurations with my team?**
A: Yes, configuration files are portable YAML files that can be shared and version controlled.

**Q: Is there an API for integration?**
A: The current version focuses on CLI and GUI interfaces. API support is planned for future releases.

**Q: How do I handle large datasets?**
A: The application is optimized for memory efficiency and can handle large SDTM datasets. Monitor system memory usage for very large files.

**Q: Can I validate against Define.xml?**
A: Define.xml validation is planned for future releases. Current version validates against SDTM datasets directly. 