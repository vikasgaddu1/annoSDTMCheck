# PowerShell script to run the SDTM Annotation Checker

# Navigate to the script's directory
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -Path $scriptPath

# Output file
$logFile = "sdtm-checker-run.log"
$outputFile = "output/validation_report.xlsx"

Write-Host "Activating virtual environment..."
try {
    # Activate the virtual environment
    & ".\.venv\Scripts\Activate.ps1"
    
    # Run the checker
    Write-Host "Running SDTM Annotation Checker..."
    sdtm-checker validate --output $outputFile *> $logFile
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Done. Validation report generated in $outputFile" -ForegroundColor Green
        Write-Host "See $logFile for detailed output."
    } else {
        Write-Host "Error occurred. See below for details:" -ForegroundColor Red
        Get-Content $logFile
    }
} catch {
    Write-Host "Error: $_" -ForegroundColor Red
} finally {
    # Deactivate the virtual environment
    if (Test-Path Env:\VIRTUAL_ENV) {
        deactivate
    }
    
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} 