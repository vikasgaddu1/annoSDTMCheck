# SDTM Annotation Checker

A Python tool for validating CRF (Case Report Form) annotations against SDTM (Study Data Tabulation Model) datasets.

## Overview

This application extracts annotations from PDF CRFs, parses them to identify SDTM domains and variables, and validates them against actual SDTM datasets (SAS7BDAT files) to identify mismatches and ensure data consistency.

## Features

- Extract annotations from PDF files
- Export annotations to XFDF format
- Parse annotations to identify SDTM domains, variables, and values
- Read and analyze SAS7BDAT files (SDTM datasets)
- Validate annotations against actual SDTM variables
- Generate comprehensive mismatch reports in Excel format

## Project Structure

```
annoSDTMCheck/
├── src/
│   └── sdtm_checker/
│       ├── core/           # Core functionality (PDF processing, XFDF conversion)
│       ├── models/         # Data models and classes
│       ├── utils/          # Utility functions
│       ├── validators/     # Validation logic
│       └── reporters/      # Report generation
├── tests/
│   ├── unit/              # Unit tests
│   ├── integration/       # Integration tests
│   └── fixtures/          # Test data
├── docs/                  # Documentation
├── config/                # Configuration files
├── scripts/               # Utility scripts
├── archive/               # Archived/deprecated code
└── output/                # Output directory for reports
```

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd annoSDTMCheck
```

2. Create a virtual environment:
```bash
# On Windows, using 'py' launcher is recommended
py -m venv .venv

# On Windows (PowerShell):
.venv\Scripts\Activate.ps1
# On Windows (Command Prompt):
.venv\Scripts\activate.bat
# On Unix/MacOS:
source .venv/bin/activate
```

3. Install dependencies:
```bash
# Make sure your virtual environment is activated before running this command.
pip install -r requirements.txt
```

## Usage

**Note**: This project uses the `py` launcher for Python on Windows. If you have multiple Python versions, ensure the correct one is used.

### Running the Application
To run the main application, use the following command:
```bash
py -m sdtm_checker --help
```

### Basic Usage

```bash
# Extract annotations from PDF to XFDF
py -m src.sdtm_checker.core.pdf2fdf --input crf/sample.pdf --output output/sample.xfdf

# Convert XFDF to Excel
py -m src.sdtm_checker.core.xfdf2xlsx --input output/sample.xfdf --output output/sample.xlsx
```

### Validating CRF Annotations

```bash
# Validate annotations against SDTM datasets
py -m sdtm_checker validate --pdf crf/acrf_myf1001.pdf --sdtm ./sdtm/ --output output/report.xlsx
```

#### Command Line Options

- `--pdf`: Path to the annotated CRF PDF file (required)
- `--sdtm`: Path to directory containing SDTM datasets (required)
- `--output`: Path to output report file (default: validation_report.xlsx)
- `--config`: Path to configuration file (defined but not yet implemented)
- `--verbose`: Enable detailed debug logging (optional)

#### Using the Batch File

For Windows users, a batch file is provided for convenience:

```bash
# Simply run the batch file
run_sdtm_checker.bat
```

This will activate the virtual environment and run the validation with predefined parameters.

## Development Status

This project is currently under active development. See [docs/TODO.md](docs/TODO.md) for the current task list and [docs/PROJECT_PLAN.md](docs/PROJECT_PLAN.md) for the development timeline.

## Contributing

Please read our contributing guidelines before submitting pull requests.

## License

[Add license information here]

## Contact

[Add contact information here] 