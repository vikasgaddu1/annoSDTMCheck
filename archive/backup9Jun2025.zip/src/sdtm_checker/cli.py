"""
Command-line interface for SDTM Annotation Checker.
"""

import logging

import os

from typing import Optional, List

import click
from rich.console import Console
from rich.logging import RichHandler

from sdtm_checker.core.annotation_extractor import AnnotationExtractor
from sdtm_checker.dynamic_annotation_parser import DynamicAnnotationParser as AnnotationParser
from sdtm_checker.sdtm_reader import SDTMDatasetManager
from sdtm_checker.validation_engine import ValidationEngine
from sdtm_checker.report_generator import ReportGenerator
from sdtm_checker.results import ValidationResult, ValidationSeverity

from sdtm_checker.config_manager import ConfigurationManager

def launch_gui() -> None:
    """Launch the graphical user interface."""
    try:
        from sdtm_checker.gui.main import main as gui_main
        console.print("🖥️  Launching SDTM Annotation Checker GUI...")
        gui_main()
    except ImportError as e:
        console.print(f"[red]Error: GUI dependencies not available: {e}[/red]")
        console.print("[yellow]Please install GUI dependencies or use the command-line interface[/yellow]")
        raise click.ClickException("GUI not available")
    except Exception as e:
        logger.error(f"Error launching GUI: {str(e)}")
        raise click.ClickException(f"Failed to launch GUI: {str(e)}")

# Set up rich console and logging
console = Console()
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(console=console, rich_tracebacks=True)]
)
logger = logging.getLogger("sdtm_checker")


def setup_logging(verbose: bool) -> None:
    """Configure logging level based on verbosity."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.getLogger().setLevel(level)

    # Configure file access logger
    file_access_logger = logging.getLogger("file_access")
    file_access_logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler("file_access.log")
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    file_access_logger.addHandler(file_handler)


def save_results(results: List[ValidationResult], output_path: str) -> None:
    """Save validation results to a file."""
    report_generator = ReportGenerator()
    report_generator.generate_report(results, output_path)
    logger.info(f"Results saved to {output_path}")


def display_results(results: List[ValidationResult]) -> None:
    """Display validation results in the console."""
    for result in results:
        severity_color = {
            ValidationSeverity.ERROR: "red",
            ValidationSeverity.WARNING: "yellow",
            ValidationSeverity.INFO: "blue"
        }.get(result.severity, "white")

        console.print(
            f"[{severity_color}]{result.severity}[/] {result.message}")


@click.group()
@click.version_option(version="1.0.0")
@click.option('--gui', is_flag=True, help='Launch the graphical user interface')
def cli(gui: bool):
    """SDTM Annotation Checker - Validate PDF annotations against SDTM datasets."""
    if gui:
        launch_gui()
        return


@cli.command()
@click.argument('sdtm-dir', type=click.Path(exists=True))
@click.argument('annotated-crf', type=click.Path(exists=True))
@click.option('--output', type=click.Path(), help='Path to save validation results')
@click.option('--config', type=click.Path(exists=True), help='Path to configuration file')
def validate(sdtm_dir: str, annotated_crf: str, output: Optional[str], config: Optional[str]):
    """Validate SDTM annotations against datasets."""
    try:
        # Initialize configuration manager
        config_manager = ConfigurationManager()
        if config:
            config_manager.load_configuration(config)
        config_data = config_manager.get_config()

        logger.info(f"Reading SDTM datasets from {sdtm_dir}")
        dataset_manager = SDTMDatasetManager(sdtm_dir)

        # Load all datasets
        datasets = {}
        for domain in dataset_manager.get_all_domains():
            dataset = dataset_manager.get_dataset(domain)
            if dataset:
                datasets[domain] = dataset

        # Get configuration values
        fuzzy_threshold = config_data.annotation_patterns["settings"]["fuzzy_threshold"]
        ignore_domains = config_data.validation.get("ignore_domains", [])
        ignore_variables = config_data.validation.get("ignore_variables", [])

        # Initialize validation engine with datasets and configuration parameters
        validation_engine = ValidationEngine(
            datasets=datasets,
            fuzzy_match_threshold=fuzzy_threshold,
            ignore_domains=ignore_domains,
            ignore_variables=ignore_variables
        )

        # Get DM variables for annotation parser
        dm_variables = dataset_manager.get_dm_variables()

        # Initialize annotation parser with DM variables and configuration
        parser = AnnotationParser(
            dm_variables=dm_variables,
            config=config_data.__dict__ if config_data else None
        )

        logger.info(f"Reading annotations from {annotated_crf}")
        extractor = AnnotationExtractor()
        raw_annotations = extractor.extract_from_pdf(annotated_crf)
        # Convert annotations to format expected by parser
        parser_annotations = [(annot.content, annot.page_number, annot.position[:2] if annot.position else None)
                              for annot in raw_annotations]
        annotations = parser.parse_annotations(parser_annotations)

        results = []
        for annotation in annotations:
            results.extend(validation_engine.validate_annotation(annotation))

        if output:
            save_results(results, output)
        else:
            display_results(results)

        logger.info("Validation complete")

    except Exception as e:
        logger.error(f"Error during validation: {str(e)}")
        raise click.ClickException(str(e))


@cli.command()
@click.argument('pdf-file', type=click.Path(exists=True))
@click.option('--output', type=click.Path(), help='Output file path')
@click.option('--format', type=click.Choice(['xfdf', 'excel']), default='xfdf', help='Output format')
def extract(pdf_file: str, output: Optional[str], format: str):
    """Extract annotations from a PDF file."""
    try:
        logger.info(f"Extracting annotations from {pdf_file}")
        extractor = AnnotationExtractor()
        annotations = extractor.extract_from_pdf(pdf_file)

        if not output:
            output = os.path.splitext(pdf_file)[0] + f".{format}"

        if format == 'xfdf':
            extractor.to_xfdf(annotations, output)
        else:
            extractor.to_excel(annotations, output)

        logger.info(f"Successfully extracted {len(annotations)} annotations")
        click.echo(f"✓ Extracted {len(annotations)} annotations to {output}")

    except Exception as e:
        logger.error(f"Error extracting annotations: {str(e)}")
        raise click.ClickException(str(e))





@cli.command()
@click.argument('sdtm-dir', type=click.Path(exists=True))
@click.option('--output', type=click.Path(), help='Path to save dataset information')
def info(sdtm_dir: str, output: Optional[str]):
    """Display information about SDTM datasets."""
    try:
        logger.info(f"Reading SDTM datasets from {sdtm_dir}")
        dataset_manager = SDTMDatasetManager(sdtm_dir)

        # Load all datasets
        datasets = {}
        for domain in dataset_manager.get_all_domains():
            dataset = dataset_manager.get_dataset(domain)
            if dataset:
                datasets[domain] = dataset

        click.echo(f"Found {len(datasets)} SDTM datasets:")
        for domain, dataset in datasets.items():
            click.echo(f"\nDomain: {domain}")
            variables = dataset.get_variable_list()
            click.echo(f"Variables: {len(variables)}")
            for var_name in variables[:5]:  # Show first 5 variables
                var_meta = dataset.get_variable_metadata(var_name)
                if var_meta:
                    click.echo(
                        f"  - {var_meta.name}: {var_meta.type} ({var_meta.length}) - {var_meta.label}")
            if len(variables) > 5:
                click.echo(f"  ... and {len(variables) - 5} more variables")

        logger.info(f"Successfully read {len(datasets)} SDTM datasets")

    except Exception as e:
        logger.error(f"Error reading SDTM datasets: {str(e)}")
        raise click.ClickException(str(e))


if __name__ == '__main__':
    cli()
