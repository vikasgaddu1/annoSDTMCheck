"""
Main entry point for the SDTM Annotation Checker.
"""

import sys
from sdtm_checker.cli import cli
from sdtm_checker.gui.main import main as gui_main

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--gui":
        gui_main()
    else:
        cli()
