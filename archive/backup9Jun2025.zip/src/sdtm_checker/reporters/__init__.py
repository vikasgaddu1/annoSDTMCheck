"""Report generation functionality."""
