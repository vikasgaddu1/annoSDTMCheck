@echo off
REM Change to O drive
o:
REM Navigate to working directory
cd O:\ToolDevelopment\annoSDTMCheck
REM Activate virtual environment and run the command in the same session
call .\.venv\Scripts\activate.bat && (
    py -m sdtm_checker validate --sdtm ./sdtm --pdf ./crf/acrf_myf1001.pdf --output output/validation_report.xlsx
    echo.
    echo Command completed.
    echo.
)
pause